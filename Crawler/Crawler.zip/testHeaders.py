# -*- coding: utf-8 -*-
'''
Created on 2016年6月17日

@author: Administrator
'''

import requests
from Requester import *

if __name__ == '__main__':
    
    
    
  


            